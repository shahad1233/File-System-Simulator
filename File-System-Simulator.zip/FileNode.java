public class FileNode extends Node {

    private String content; // The text stored inside the file
    private int size; // Size of the file (content length)

    // Constructor: creates a new file with a given name, parent, and initial size
    public FileNode(String name, Directory parent, int size) {
        super(name, parent); // Initialize name + parent from Node
        this.size = size; // Initial size
        this.content = ""; // Files start empty until written
    }

    // Returns the current content of the file
    public String getContent() {
        return content;
    }

    // Updates the file's content and updates its size
    public void setContent(String content) {
        this.content = content;
        this.size = content.length(); // size depends on content length
    }

    // used to update file size
    public void setSize(int size) {
        this.size = size;
    }

    // Returns the size of the file in bytes (number of characters)
    @Override
    public int getSize() {
        return size;
    }
}