import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Collection;

public class Directory extends Node {

    // Map for fast access: name --> Node (file or directory)
    private Map<String, Node> children;

    // Keeps children in insertion order for commands like 'ls' and 'tree'
    private ArrayList<Node> order;

    // Constructor: creates a directory with empty children
    public Directory(String name, Directory parent) {
        super(name, parent);
        this.children = new HashMap<>();
        this.order = new ArrayList<>();
    }

    // Adds a new child node (file or directory) to this directory
    public void addChild(Node child) {
        if (!children.containsKey(child.getName())) { //Prevents duplicates
            children.put(child.getName(), child); // add to map
            order.add(child); // add to order list
            child.setParent(this); // update parent link
        }
    }


    // Removes a child by name from both the map and the order list
    public void removeChild(String name) {
        Node removed = children.remove(name); // remove from map
        if (removed != null) {
            order.remove(removed); // also remove from order list
        }
    }


    // Returns the children in the order they were added.
    // Returned as a new list to avoid external modifications.
    public ArrayList<Node> getChildrenInOrder() {
        return new ArrayList<>(order);
    }

    // Returns a child node by its name, or null if it doesn't exist
    public Node getChild(String name) {
        return children.get(name);
    }

    // Returns a collection of all child nodes (no order guarantee)
    public Collection<Node> getChildren() {
        return children.values();
    }

    // Checks if the directory has no children
    public boolean isEmpty() {
        return children.isEmpty();
    }


    // Returns the total size of all nodes inside the directory
    // For files, size is file size
    // For subdirectories, it calls their getSize() recursively
    @Override
    public int getSize() {
        int total = 0;

        for (Node node : children.values()) {
            total += node.getSize();
        }

        return total;
    }
}

