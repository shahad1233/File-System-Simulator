import java.util.ArrayList;
import java.util.EmptyStackException;

public class myStack<T> {

    private ArrayList<T> pool;

    // Constructor: initializes an empty stack
    public myStack() {
        pool = new ArrayList<T>();
    }

    // Returns true if the stack has no elements
    public boolean isEmpty() {
        return pool.isEmpty();
    }

    // Removes and returns the top element of the stack
    public T pop() {
        if (isEmpty()) {
            throw new EmptyStackException(); // Throws EmptyStackException if the stack is empty
        }
        return pool.remove(pool.size() - 1); // remove last element
    }

    // Pushes a new element onto the top of the stack
    public void push(T el) {
        pool.add(el);
    }

    // Returns the top element of the stack
    public T peek() {
        if (isEmpty())
            throw new java.util.EmptyStackException(); // Throws EmptyStackException if the stack is empty
        return pool.get(pool.size()-1); // access last element
    }

    // Returns the number of elements in the stack
    public int size(){
        return pool.size();
    }

}

