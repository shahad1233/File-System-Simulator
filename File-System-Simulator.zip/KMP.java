public class KMP {

    public static String searchKMP(String pattern, String text) {

        int M = pattern.length(); // length of pattern
        int N = text.length(); // length of text
        String indexes = ""; // stores matching starting positions

        int[] lps = computeLPSArray(pattern);

        int i = 0; // index for text
        int j = 0; // index for pattern

        // Main KMP loop
        while (i < N) {

            // if characters match, move both pointers
            if (pattern.charAt(j) == text.charAt(i)) {
                j++;
                i++;
            }

            // A full match was found
            if (j == M) {
                indexes += (i - j) + "  "; // record match index
                j = lps[j - 1]; // continue searching using LPS
            }

            // Mismatch after j matches
            else if (i < N && pattern.charAt(j) != text.charAt(i)) {

                // Move j back using LPS until match is possible
                if (j != 0) {
                    j = lps[j - 1];
                }
                // If j == 0 , just move text pointer
                else {
                    i = i + 1;
                }
            }
        }

        // No matches found
        if (indexes.isEmpty()) {
            return null;
        }
        return indexes;
    }

    static int[] computeLPSArray(String pattern) {
        int M = pattern.length();
        int[] lps = new int[M];

        int len = 0; // length of current longest prefix-suffix
        int i = 1;
        lps[0] = 0; // first entry is always 0

        // Build LPS array
        while (i < M) {

            // if characters match, extend the prefix-suffix
            if (pattern.charAt(i) == pattern.charAt(len)) {
                len++;
                lps[i] = len;
                i++;
            }

            // Mismatch
            else {
                if (len != 0) {
                    len = lps[len - 1]; // try shorter prefix
                }

                else {
                    lps[i] = len;
                    i++;
                }
            }
        }

        return lps;
    }
}
