import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        FileSystem fs = new FileSystem(); // Create a new filesystem instance

        while (true) {

            System.out.print(fs.getPrompt());

            String input = sc.nextLine().trim(); // Read user input

            // Skip empty input
            if (input.isEmpty()) {
                continue;
            }
            // Exit command
            if (input.equals("exit")) {
                break;
            }

            // Split command by spaces
            String[] parts = input.split("\\s+");
            String cmd = parts[0];

            // dealing with commands
            switch (cmd) {

                //  mkdir / mkdir -p
                case "mkdir":
                    if (parts.length >= 2 && parts[1].equals("-p")) {
                        if (parts.length == 3) {
                            fs.makeDirectry_p(parts[2]);
                        } else {
                            System.out.println("Usage: mkdir -p <path>");
                        }

                    } else if (parts.length >= 2) {
                        for (int i = 1; i < parts.length; i++) {
                            fs.makeDirectry(parts[i]);
                        }
                    } else {
                        System.out.println("Usage: mkdir <dir_name>");
                    }
                    break;

                //  ls
                case "ls":
                    fs.ls();
                    break;

                //  cd
                case "cd":
                    if (parts.length == 2) {
                        fs.cd(parts[1]);
                    } else {
                        System.out.println("Usage: cd <path>");
                    }
                    break;

                // touch
                case "touch":
                    if (parts.length == 3) {
                        try {
                            int size = Integer.parseInt(parts[2]);
                            fs.touch(parts[1], size);
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid size");
                        }
                    } else {
                        System.out.println("Usage: touch <file_name> <size>");
                    }
                    break;

                // echo "text" > file
                case "echo":
                    int q1 = input.indexOf('"');
                    int q2 = input.indexOf('"', q1 + 1);
                    int arrow = input.indexOf('>', q2 + 1);

                    if (q1 != -1 && q2 != -1 && arrow != -1) {
                        String text = input.substring(q1 + 1, q2);
                        String path = input.substring(arrow + 1).trim();
                        fs.echo(text, path);
                    } else {
                        System.out.println("Usage: echo \"text\" > file");
                    }
                    break;

                // grep
                case "grep":
                    int g1 = input.indexOf('"');
                    int g2 = input.indexOf('"', g1 + 1);

                    if (g1 != -1 && g2 != -1) {
                        String pattern = input.substring(g1 + 1, g2);
                        String after = input.substring(g2 + 1).trim();
                        if (!after.isEmpty()) {
                            String fileName = after.split("\\s+")[0];
                            fs.grep(pattern, fileName);
                        } else {
                            System.out.println("Usage: grep \"pattern\" file");
                        }

                    } else if (parts.length == 3) {
                        fs.grep(parts[1], parts[2]);
                    } else {
                        System.out.println("Usage: grep \"pattern\" file");
                    }
                    break;

                // rm / rm -r
                case "rm":
                    if (parts.length == 2) {
                        fs.remove(parts[1]);
                    } else if (parts.length == 3 && parts[1].equals("-r")) {
                        fs.remove_r(parts[2]);
                    } else {
                        System.out.println("Usage: rm <name> OR rm -r <dir_name>");
                    }
                    break;

                // du
                case "du":
                    fs.displaySize();
                    break;

                // pwd
                case "pwd":
                    fs.findPath();
                    break;

                // tree
                case "tree":
                    fs.tree();
                    break;

                default: // Unknown command
                    System.out.println("Unknown command: " + cmd);
            }
        }

        sc.close(); //close scanner
    }
}

