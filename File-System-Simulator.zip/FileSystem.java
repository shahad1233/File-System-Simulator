import java.util.*;

public class FileSystem {

    private Directory root; // Main root directory
    private Directory currentDirectory; // Tracks where the user currently is

    public FileSystem() {
        root = new Directory("/", null); // Create the root directory
        currentDirectory = root; // Set current directory to root
    }

    public Directory getRoot() {
        return root;
    }

    public Directory getCurrentDirectory() {
        return currentDirectory;
    }

    public void setCurrentDirectory(Directory dir) {
        this.currentDirectory = dir;
    }

    // Grep: search for a pattern inside a file using KMP algorithm
    public void grep(String pattern, String fileName) {

        Node child = currentDirectory.getChild(fileName); // get file from current directory

        if (child == null) { // file not found
            System.out.println("File not found");
            return;
        }

        if (!(child instanceof FileNode)) { // cannot grep a directory
            System.out.println("Cannot grep a directory");
            return;
        }

        String content = ((FileNode) child).getContent(); // read file content

        // run KMP search
        String resultFromSearch = KMP.searchKMP(pattern, content);

        if (resultFromSearch == null) {
            System.out.println("Pattern \"" + pattern + "\" not found in " + fileName + ".");
        } else {
            System.out.println("Pattern \"" + pattern + "\" found in " + fileName + ".");
        }
    }

    // findPath (pwd): prints the full path of the current directory
    public void findPath() {

        myStack<String> stack = new myStack<String>(); // stack to build path
        Directory temp = currentDirectory;

        // push directory names until reaching root
        while (temp != null) {
            stack.push(temp.getName());
            temp = temp.getParent();
        }

        String path = "";

        // pop from stack to create correct path order
        while (!stack.isEmpty()) {
            String part = stack.pop();

            if (path.isEmpty()) { // first part
                if (part.equals("/")) {
                    path = "/";
                } else {
                    path = "/" + part;
                }
            } else {
                if (path.equals("/")) {
                    path = path + part;
                } else {
                    path = path + "/" + part;
                }
            }
        }

        System.out.println(path);
    }

    //ls: lists files and directories in the current directory
    public void ls() {

        for (Node node : currentDirectory.getChildrenInOrder()) {

            if (node instanceof Directory) {
                System.out.print(node.getName() + "/   "); // add "/" for folders
            } else if (node instanceof FileNode) {
                System.out.print(node.getName() + " (" + node.getSize() + "B)   "); // show size
            }
        }
        System.out.println();
    }


    // echo: writes/overwrites content into a file, creates file if absent
    public void echo(String text, String filePath) {

        Directory dir = currentDirectory;
        String fileName = filePath;

        // handling nested paths like a/b/c.txt
        if (filePath.contains("/")) {

            String[] parts = filePath.split("/");

            for (int i = 0; i < parts.length; i++) {

                String part = parts[i];

                if (part.equals("") || part.equals(".")) {
                    continue;
                }

                if (i == parts.length - 1) {
                    fileName = part; // last part is file name
                } else {
                    Node child = dir.getChild(part);

                    // directory not found
                    if (child == null || !(child instanceof Directory)) {
                        System.out.println("Error: directory '" + part + "' not found.");
                        return;
                    }

                    dir = (Directory) child; // go into directory
                }
            }
        }

        Node child = dir.getChild(fileName);

        //if file does not exist, create new
        if (child == null) {
            FileNode newFile = new FileNode(fileName, dir, text.length());
            newFile.setContent(text);
            dir.addChild(newFile);

        } else {
            // cannot overwrite directory
            if (!(child instanceof FileNode)) {
                System.out.println("Error: '" + fileName + "' is not a file.");
                return;
            }

            ((FileNode) child).setContent(text); // overwrite content
        }
    }

    // mkdir: creates a directory (no / allowed without -p)
    public void makeDirectry(String name) {

        if (name.contains("/")) {
            System.out.println("Error: mkdir without -p cannot create a path.");
            return;
        }

        if (!Character.isLetter(name.charAt(0))){
            System.out.println("Directory must start with a letter");
            return;
        }

        // check if it already exists
        Node existing = currentDirectory.getChild(name);
        if (existing != null) {
            System.out.println("Error: '" + name + "' already exists.");
            return;
        }

        Directory newDir = new Directory(name, currentDirectory);
        currentDirectory.addChild(newDir);
    }

    //mkdir -p: creates full nested path, creating parent directories as needed
    public void makeDirectry_p(String path) {

        Directory start;

        // absolute path
        if (path.startsWith("/")) {
            start = root;
            path = path.substring(1);
        } else {
            start = currentDirectory;
        }

        if (path.isEmpty()) {
            return;
        }

        if (!Character.isLetter(path.charAt(0))){
            System.out.println("Directory must start with a letter");
            return;
        }

        String[] parts = path.split("/");
        Directory current = start;

        for (String part : parts) {

            if (part.equals("") || part.equals(".")) {
                continue;
            }

            Node child = current.getChild(part);

            if (child == null) {
                // create directory if missing
                Directory newDir = new Directory(part, current);
                current.addChild(newDir);
                current = newDir;

            } else {
                // must be directory
                if (!(child instanceof Directory)) {
                    System.out.println("Error: '" + part + "' is not a directory.");
                    return;
                }
                current = (Directory) child;
            }
        }
    }



    // rm: removes file or empty directory only
    public void remove(String name) {

        Node child = currentDirectory.getChild(name);

        if (child == null) {
            System.out.println("Error: '" + name + "' not found.");
            return;
        }

        // cannot remove directory with content
        if (child instanceof Directory) {
            Directory dir = (Directory) child;
            if (!dir.isEmpty()) {
                System.out.println("Error: Cannot remove directory '" + name + "'. It is not empty.");
                return;
            }
        }

        currentDirectory.removeChild(name);

    }

    //helper: recursively delete all children
    private void deleteRecursively(Directory dir) {

        ArrayList<String> names = new ArrayList<>();

        // collect names first to avoid concurrent modification
        for (Node child : dir.getChildren()) {
            names.add(child.getName());
        }

        // delete each child
        for (String childName : names) {

            Node child = dir.getChild(childName);

            if (child instanceof Directory) {
                deleteRecursively((Directory) child); // recursive deletion
            }

            dir.removeChild(childName);
        }
    }

    // rm -r: removes a directory and all its contents
    public void remove_r(String dirName) {

        Node child = currentDirectory.getChild(dirName);

        if (child == null) {
            System.out.println("Error: directory not found");
            return;
        }

        if (!(child instanceof Directory)) {
            System.out.println("Error: '" + dirName + "' is not a directory");
            return;
        }

        Directory dir = (Directory) child;

        deleteRecursively(dir); // delete contents
        currentDirectory.removeChild(dirName);
    }

    //get total size of all files under a directory (recursive)
    private int getDirectorySize(Directory dir) {

        int total = 0;

        for (Node child : dir.getChildren()) {

            if (child instanceof FileNode) {
                total += child.getSize(); // add file size
            }
            else if (child instanceof Directory) {
                total += getDirectorySize((Directory) child); // add subdirectory size
            }
        }

        return total;
    }

    // show total size of the current directory
    public void displaySize() {
        int size = getDirectorySize(currentDirectory);
        System.out.println("Total size: " + size + "B");
    }

    // Builds the prompt path
    public String getPrompt() {

        // root case
        if (currentDirectory == root || currentDirectory.getParent() == null) {
            return "/$ ";
        }

        java.util.Stack<String> stack = new java.util.Stack<>();
        Directory temp = currentDirectory;


        // push names upwards until root
        while (temp != null && temp != root) {
            stack.push(temp.getName());
            temp = temp.getParent();
        }

        StringBuilder path = new StringBuilder("/");

        // build path in correct order
        while (!stack.isEmpty()) {
            path.append(stack.pop());
            if (!stack.isEmpty()) {
                path.append("/");
            }
        }

        return path.toString() + "$ ";
    }

    // Prints the directory tree starting from the current directory
    public void tree() {
        System.out.println(".");
        printTree(currentDirectory, "", true);
    }

    // helper to print children with formatting
    private void printTree(Directory dir, String prefix, boolean isLastFromParent) {

        ArrayList<Node> children = dir.getChildrenInOrder();

        if (children.isEmpty()) {
            return;
        }

        for (int i = 0; i < children.size(); i++) {
            Node child = children.get(i);
            boolean isLast = (i == children.size() - 1);

            String connector = isLast ? "└── " : "├── ";

            String displayName;
            if (child instanceof Directory) {
                displayName = child.getName() + "/";
            } else {
                displayName = child.getName() + " (" + child.getSize() + "B)";
            }

            // print this item
            System.out.println(prefix + connector + displayName);

            // if directory, go deeper
            if (child instanceof Directory) {
                String newPrefix = prefix + (isLast ? "    " : "│   ");
                printTree((Directory) child, newPrefix, isLast);
            }
        }
    }

    // touch: creates a new empty file if it doesn't exist
    public void touch(String filePath, int size) {

        Directory dir = currentDirectory;
        String fileName = filePath;

        // handle nested paths
        if (filePath.contains("/")) {

            String[] parts = filePath.split("/");

            for (int i = 0; i < parts.length; i++) {

                String part = parts[i];

                if (part.equals("") || part.equals(".")) {
                    continue;
                }

                if (i == parts.length - 1) {
                    fileName = part; // last part is file name
                } else {

                    Node child = dir.getChild(part);

                    if (child == null || !(child instanceof Directory)) {
                        System.out.println("Error: directory '" + part + "' not found.");
                        return;
                    }

                    dir = (Directory) child; // go inside directory
                }
            }
        }
        Node child = dir.getChild(fileName);

        if (child != null) {
            return; // if file exists, do nothing

        } else {

            // create new file
            FileNode newFile = new FileNode(fileName, dir, size);
            dir.addChild(newFile);
        }
    }

    // cd: changes the current directory (supports absolute and relative paths)
    public void cd(String path) {

        Directory startDirectory;

        // absolute path
        if (path.startsWith("/")) {
            startDirectory = root;
            path = path.substring(1);
        } else {
            startDirectory = currentDirectory;
        }

        String originalPath = path;

        String[] parts = path.split("/");

        myStack<Directory> stack = new myStack<>();
        stack.push(startDirectory);

        for (String part : parts) {

            if (part.equals("") || part.equals(".")) {
                continue;  //ignore
            }
            else if (part.equals("..")) { // go to parent

                Directory top = stack.peek();
                Directory parent = top.getParent();

                if (parent != null) { // cannot go above root
                    stack.pop();
                    stack.push(parent);
                }
            } else {
                Directory top = stack.peek();
                Node child = top.getChild(part);

                if (child == null) { // folder not found
                    System.out.println("Error: Path '/" + originalPath + "' not found.");
                    return;
                }

                if (!(child instanceof Directory)) { // not a folder
                    System.out.println("Error: '" + part + "' is not a directory.");
                    return;
                }

                stack.push((Directory) child); // go inside

            }
        }
        currentDirectory = stack.peek(); // update current directory
    }
}

