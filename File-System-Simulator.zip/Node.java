
// Node (Abstract Class):
// Represents a file system node (either a FileNode or Directory)
// Stores the common properties shared by both: name + parent directory
// Each subclass must implement getSize()
public abstract class Node {

    protected String name; // Name of the file or directory
    protected Directory parent; // Reference to parent directory


    // Constructor: initializes the node with a name and its parent
    public Node(String name, Directory parent) {
        this.name = name;
        this.parent = parent;
    }

    // Returns the name of the node (file name or directory name)
    public String getName() {
        return name;
    }

    // Returns the parent directory of this node
    public Directory getParent() {
        return parent;
    }

    // Updates the parent of this node (used when moving a file/directory)
    public void setParent(Directory parent) {
        this.parent = parent;
    }


    // Abstract: each subclass must return its size
    // For FileNode, returns file size
    // For Directory, returns cumulative size of contents
    public abstract int getSize();
}
